java -cp appClient-module-1.9-SNAPSHOT.jar:libs/* com.osrmt.appclient.reqmanager.RequirementManagerController
